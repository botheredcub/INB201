update Events_T
set EventStatus = 'high', 
Event_updated_Date = '2013-05-06 15:01:22'
where (Event_ID = '1000001');
-- insert the eventid in '' to change a particular event. 