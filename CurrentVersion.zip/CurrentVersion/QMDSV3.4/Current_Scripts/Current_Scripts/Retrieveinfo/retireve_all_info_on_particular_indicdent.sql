select distinct * from personnel  natural join events_t 
natural join event_type natural join location natural join services;