select distinct* from events_t natural join event_type natural join location 
natural join incidents natural join personnel;

