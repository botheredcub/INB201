﻿namespace WindowsFormsApplication1
{
    partial class Personnel_Management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.First_name_label = new System.Windows.Forms.Label();
            this.Last_name_label = new System.Windows.Forms.Label();
            this.Middle_name_label = new System.Windows.Forms.Label();
            this.Address_label = new System.Windows.Forms.Label();
            this.City_label = new System.Windows.Forms.Label();
            this.Password_label = new System.Windows.Forms.Label();
            this.Access_level_label = new System.Windows.Forms.Label();
            this.Postcode_label = new System.Windows.Forms.Label();
            this.Gender_label = new System.Windows.Forms.Label();
            this.Email_label = new System.Windows.Forms.Label();
            this.Acc_code_label = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // First_name_label
            // 
            this.First_name_label.AutoSize = true;
            this.First_name_label.Location = new System.Drawing.Point(96, 99);
            this.First_name_label.Name = "First_name_label";
            this.First_name_label.Size = new System.Drawing.Size(63, 13);
            this.First_name_label.TabIndex = 0;
            this.First_name_label.Text = "First Name: ";
            // 
            // Last_name_label
            // 
            this.Last_name_label.AutoSize = true;
            this.Last_name_label.Location = new System.Drawing.Point(95, 124);
            this.Last_name_label.Name = "Last_name_label";
            this.Last_name_label.Size = new System.Drawing.Size(64, 13);
            this.Last_name_label.TabIndex = 1;
            this.Last_name_label.Text = "Last Name: ";
            // 
            // Middle_name_label
            // 
            this.Middle_name_label.AutoSize = true;
            this.Middle_name_label.Location = new System.Drawing.Point(96, 146);
            this.Middle_name_label.Name = "Middle_name_label";
            this.Middle_name_label.Size = new System.Drawing.Size(75, 13);
            this.Middle_name_label.TabIndex = 2;
            this.Middle_name_label.Text = "Middle Name: ";
            // 
            // Address_label
            // 
            this.Address_label.AutoSize = true;
            this.Address_label.Location = new System.Drawing.Point(96, 172);
            this.Address_label.Name = "Address_label";
            this.Address_label.Size = new System.Drawing.Size(48, 13);
            this.Address_label.TabIndex = 3;
            this.Address_label.Text = "Address:";
            // 
            // City_label
            // 
            this.City_label.AutoSize = true;
            this.City_label.Location = new System.Drawing.Point(96, 192);
            this.City_label.Name = "City_label";
            this.City_label.Size = new System.Drawing.Size(27, 13);
            this.City_label.TabIndex = 4;
            this.City_label.Text = "City:";
            // 
            // Password_label
            // 
            this.Password_label.AutoSize = true;
            this.Password_label.Location = new System.Drawing.Point(96, 54);
            this.Password_label.Name = "Password_label";
            this.Password_label.Size = new System.Drawing.Size(56, 13);
            this.Password_label.TabIndex = 6;
            this.Password_label.Text = "Password:";
            // 
            // Access_level_label
            // 
            this.Access_level_label.AutoSize = true;
            this.Access_level_label.Location = new System.Drawing.Point(96, 74);
            this.Access_level_label.Name = "Access_level_label";
            this.Access_level_label.Size = new System.Drawing.Size(74, 13);
            this.Access_level_label.TabIndex = 7;
            this.Access_level_label.Text = "Access Level:";
            // 
            // Postcode_label
            // 
            this.Postcode_label.AutoSize = true;
            this.Postcode_label.Location = new System.Drawing.Point(96, 215);
            this.Postcode_label.Name = "Postcode_label";
            this.Postcode_label.Size = new System.Drawing.Size(59, 13);
            this.Postcode_label.TabIndex = 8;
            this.Postcode_label.Text = "Post Code:";
            // 
            // Gender_label
            // 
            this.Gender_label.AutoSize = true;
            this.Gender_label.Location = new System.Drawing.Point(95, 239);
            this.Gender_label.Name = "Gender_label";
            this.Gender_label.Size = new System.Drawing.Size(45, 13);
            this.Gender_label.TabIndex = 9;
            this.Gender_label.Text = "Gender:";
            // 
            // Email_label
            // 
            this.Email_label.AutoSize = true;
            this.Email_label.Location = new System.Drawing.Point(436, 80);
            this.Email_label.Name = "Email_label";
            this.Email_label.Size = new System.Drawing.Size(35, 13);
            this.Email_label.TabIndex = 10;
            this.Email_label.Text = "Email:";
            // 
            // Acc_code_label
            // 
            this.Acc_code_label.AutoSize = true;
            this.Acc_code_label.Location = new System.Drawing.Point(436, 51);
            this.Acc_code_label.Name = "Acc_code_label";
            this.Acc_code_label.Size = new System.Drawing.Size(75, 13);
            this.Acc_code_label.TabIndex = 11;
            this.Acc_code_label.Text = "Account Code";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(187, 51);
            this.textBox1.MaxLength = 10;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 12;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(187, 103);
            this.textBox3.MaxLength = 40;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 14;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(187, 129);
            this.textBox4.MaxLength = 40;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 15;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(187, 155);
            this.textBox5.MaxLength = 120;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 16;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(187, 212);
            this.textBox7.MaxLength = 40;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 18;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(527, 77);
            this.textBox2.MaxLength = 60;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(163, 20);
            this.textBox2.TabIndex = 19;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(187, 76);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 20;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(187, 184);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 21;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(187, 238);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 22;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(527, 48);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 23;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(527, 124);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "Add new users to the database";
            // 
            // Personnel_Management
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 340);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Acc_code_label);
            this.Controls.Add(this.Email_label);
            this.Controls.Add(this.Gender_label);
            this.Controls.Add(this.Postcode_label);
            this.Controls.Add(this.Access_level_label);
            this.Controls.Add(this.Password_label);
            this.Controls.Add(this.City_label);
            this.Controls.Add(this.Address_label);
            this.Controls.Add(this.Middle_name_label);
            this.Controls.Add(this.Last_name_label);
            this.Controls.Add(this.First_name_label);
            this.Name = "Personnel_Management";
            this.Text = "People Management";
            this.Load += new System.EventHandler(this.People_Management_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label First_name_label;
        private System.Windows.Forms.Label Last_name_label;
        private System.Windows.Forms.Label Middle_name_label;
        private System.Windows.Forms.Label Address_label;
        private System.Windows.Forms.Label City_label;
        private System.Windows.Forms.Label Password_label;
        private System.Windows.Forms.Label Access_level_label;
        private System.Windows.Forms.Label Postcode_label;
        private System.Windows.Forms.Label Gender_label;
        private System.Windows.Forms.Label Email_label;
        private System.Windows.Forms.Label Acc_code_label;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
    }
}